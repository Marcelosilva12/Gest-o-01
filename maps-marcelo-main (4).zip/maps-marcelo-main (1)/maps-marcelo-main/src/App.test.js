import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import App from './App';

describe('App Component', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  test('displays alert when user is not registered', () => {
    const alertMock = jest.spyOn(window, 'alert').mockImplementation();

    render(<App />);
    
    fireEvent.change(screen.getByPlaceholderText(/coloque seu email/i), { target: { value: 'test@example.com' } });
    fireEvent.change(screen.getByPlaceholderText(/coloque sua senha/i), { target: { value: 'password123' } });
    fireEvent.click(screen.getByText(/enviar/i));
    
    expect(alertMock).toHaveBeenCalledWith('Usuário não cadastrado!');
    
    alertMock.mockRestore();
  });

  test('displays alert when credentials are incorrect', () => {
    localStorage.setItem('userInfos', JSON.stringify({ email: 'test@example.com', password: 'password123' }));
    const alertMock = jest.spyOn(window, 'alert').mockImplementation();

    render(<App />);
    
    fireEvent.change(screen.getByPlaceholderText(/coloque seu email/i), { target: { value: 'wrong@example.com' } });
    fireEvent.change(screen.getByPlaceholderText(/coloque sua senha/i), { target: { value: 'wrongpassword' } });
    fireEvent.click(screen.getByText(/enviar/i));
    
    expect(alertMock).toHaveBeenCalledWith('Credenciais incorretas!');
    
    alertMock.mockRestore();
  });

  test('redirects to /map when credentials are correct', () => {
    localStorage.setItem('userInfos', JSON.stringify({ email: 'test@example.com', password: 'password123' }));
    delete window.location;
    window.location = { href: jest.fn() };

    render(<App />);
    
    fireEvent.change(screen.getByPlaceholderText(/coloque seu email/i), { target: { value: 'test@example.com' } });
    fireEvent.change(screen.getByPlaceholderText(/coloque sua senha/i), { target: { value: 'password123' } });
    fireEvent.click(screen.getByText(/enviar/i));
    
    expect(window.location.href).toBe('/map');
  });

  test('renders link to register page', () => {
    render(<App />);
    expect(screen.getByText(/ainda não cadastrado\?/i)).toHaveAttribute('href', '/register');
  });
});
