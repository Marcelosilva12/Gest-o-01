@react-google-maps/api-mock
import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Map from './Map';
import { LoadScriptNext } from '@react-google-maps/api';

jest.mock('@react-google-maps/api', () => ({
  GoogleMap: (props) => <div>{props.children}</div>,
  LoadScript: (props) => <div>{props.children}</div>,
}));

jest.mock('./MarkerMap', () => {
  return ({ location, label }) => (
    <div data-testid="marker" data-label={label} />
  );
});

describe('Map Component', () => {''
  it('renders map with markers', async () => {
    render(<Map />);

    await waitFor(() => {
      const markers = screen.getAllByTestId('marker');
      expect(markers).toHaveLength(5);
      expect(markers[0]).toHaveAttribute('data-label', 'Mata Escura');
      expect(markers[1]).toHaveAttribute('data-label', 'São Critovão');
      expect(markers[2]).toHaveAttribute('data-label', 'Sussuarana');
      expect(markers[3]).toHaveAttribute('data-label', 'Itapuã');
      expect(markers[4]).toHaveAttribute('data-label', 'Lobato');
    });
  });

  it('redirects to home if no user info is in localStorage', () => {
    Object.defineProperty(window, 'localStorage', {
      value: {
        getItem: jest.fn(() => null),
      },
      writable: true,
    });

    const { container } = render(<Map />);
    
    expect(window.location.href).toBe('/');
  });

  it('does not redirect if user info is in localStorage', () => {
    Object.defineProperty(window, 'localStorage', {
      value: {
        getItem: jest.fn(() => JSON.stringify({ user: 'test' })),
      },
      writable: true,
    });

    const { container } = render(<Map />);
    
    expect(window.location.href).not.toBe('/');
  });
});
