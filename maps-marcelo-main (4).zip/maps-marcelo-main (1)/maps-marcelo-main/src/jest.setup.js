// jest.setup.js
import { mockLoadScript, mockGoogleMapsAPI } from '@react-google-maps/api-mock';

global.URL.createObjectURL = jest.fn(); 

mockLoadScript();

mockGoogleMapsAPI();
