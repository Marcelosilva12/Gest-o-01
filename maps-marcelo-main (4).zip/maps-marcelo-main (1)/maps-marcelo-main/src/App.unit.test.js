import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import App from './App';

describe('App Component Unit Tests', () => {

  test('updates state on email input change', () => {
    render(<App />);
    
    const emailInput = screen.getByPlaceholderText(/coloque seu email/i);
    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    
    expect(emailInput.value).toBe('test@example.com');
  });

  test('updates state on password input change', () => {
    render(<App />);
    
    const passwordInput = screen.getByPlaceholderText(/coloque sua senha/i);
    fireEvent.change(passwordInput, { target: { value: 'password123' } });
    
    expect(passwordInput.value).toBe('password123');
  });

  test('displays alert when form is submitted with empty localStorage', () => {
    const alertMock = jest.spyOn(window, 'alert').mockImplementation();

    render(<App />);
    
    const emailInput = screen.getByPlaceholderText(/coloque seu email/i);
    const passwordInput = screen.getByPlaceholderText(/coloque sua senha/i);
    const submitButton = screen.getByText(/enviar/i);
    
    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password123' } });
    fireEvent.click(submitButton);
    
    expect(alertMock).toHaveBeenCalledWith('Usuário não cadastrado!');
    
    alertMock.mockRestore();
  });

  test('calls window.location.href when form is submitted with correct credentials', () => {
    localStorage.setItem('userInfos', JSON.stringify({ email: 'test@example.com', password: 'password123' }));
    delete window.location;
    window.location = { href: jest.fn() };

    render(<App />);
    
    const emailInput = screen.getByPlaceholderText(/coloque seu email/i);
    const passwordInput = screen.getByPlaceholderText(/coloque sua senha/i);
    const submitButton = screen.getByText(/enviar/i);
    
    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password123' } });
    fireEvent.click(submitButton);
    
    expect(window.location.href).toBe('/map');
  });

  test('renders link to register page', () => {
    render(<App />);
    expect(screen.getByText(/ainda não cadastrado\?/i)).toHaveAttribute('href', '/register');
  });
});
