import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { createMemoryRouter, RouterProvider } from 'react-router-dom';
import App from './App';
import Map from './components/Map';
import Register from './components/Register';

const routes = [
  { path: "/", element: <App /> },
  { path: "/map", element: <Map /> },
  { path: "/register", element: <Register /> }
];

const renderWithRouter = (initialEntries) => {
  const router = createMemoryRouter(routes, { initialEntries });
  return render(<RouterProvider router={router} />);
};

describe('App Integration Tests', () => {
  test('renders App component at / route', () => {
    renderWithRouter(['/']);
    expect(screen.getByPlaceholderText(/coloque seu email/i)).toBeInTheDocument();
    expect(screen.getByPlaceholderText(/coloque sua senha/i)).toBeInTheDocument();
    expect(screen.getByText(/ainda não cadastrado\?/i)).toBeInTheDocument();
  });

  test('navigates to /register when link is clicked', () => {
    renderWithRouter(['/']);
    fireEvent.click(screen.getByText(/ainda não cadastrado\?/i));
    expect(screen.getByText(/registro/i)).toBeInTheDocument();
  });

  test('displays alert and stays on / when user is not registered', () => {
    const alertMock = jest.spyOn(window, 'alert').mockImplementation();

    renderWithRouter(['/']);
    fireEvent.change(screen.getByPlaceholderText(/coloque seu email/i), { target: { value: 'test@example.com' } });
    fireEvent.change(screen.getByPlaceholderText(/coloque sua senha/i), { target: { value: 'password123' } });
    fireEvent.click(screen.getByText(/enviar/i));
    
    expect(alertMock).toHaveBeenCalledWith('Usuário não cadastrado!');
    expect(screen.getByPlaceholderText(/coloque seu email/i)).toBeInTheDocument();
    alertMock.mockRestore();
  });

  test('navigates to /map when correct credentials are provided', () => {
    localStorage.setItem('userInfos', JSON.stringify({ email: 'test@example.com', password: 'password123' }));
    renderWithRouter(['/']);
    
    fireEvent.change(screen.getByPlaceholderText(/coloque seu email/i), { target: { value: 'test@example.com' } });
    fireEvent.change(screen.getByPlaceholderText(/coloque sua senha/i), { target: { value: 'password123' } });
    fireEvent.click(screen.getByText(/enviar/i));
    
    expect(screen.getByText(/mapa/i)).toBeInTheDocument(); // Assume que o componente Map tem o texto "mapa" ou similar
  });

  test('displays alert and stays on / when incorrect credentials are provided', () => {
    localStorage.setItem('userInfos', JSON.stringify({ email: 'test@example.com', password: 'password123' }));
    const alertMock = jest.spyOn(window, 'alert').mockImplementation();

    renderWithRouter(['/']);
    
    fireEvent.change(screen.getByPlaceholderText(/coloque seu email/i), { target: { value: 'wrong@example.com' } });
    fireEvent.change(screen.getByPlaceholderText(/coloque sua senha/i), { target: { value: 'wrongpassword' } });
    fireEvent.click(screen.getByText(/enviar/i));
    
    expect(alertMock).toHaveBeenCalledWith('Credenciais incorretas!');
    expect(screen.getByPlaceholderText(/coloque seu email/i)).toBeInTheDocument();
    alertMock.mockRestore();
  });
});
